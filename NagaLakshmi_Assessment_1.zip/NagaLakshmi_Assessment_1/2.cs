﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NagaLakshmi_Assessment_1
{
    internal class _2
    {
       
         static void Main(string[] args)
        {
            int[,] a = new int[3,3];
            a[0,0] = 1;
            a[0,1] = 2;
            a[0,2] = 3;
            a[1,0]= 4;
            a[1,1] = 5;
            a[1,2] = 6;
            a[2,0]= 7;
            a[2,1]= 8;
            a[2,2] = 9;

            for(int i = 0; i < a.GetLength(0); i++)
            {
                 for(int j = 0; j < a.GetLength(1); j++)
                {
                    Console.WriteLine(a[i, j]);
                }
                Console.WriteLine();
            }

        }
    }
}
