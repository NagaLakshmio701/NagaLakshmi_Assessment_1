﻿namespace NagaLakshmi_Assessment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double balance = 1000.00;
            double interest = 0.05;
            double target = 100000;
            int years = 0;




            while (balance <= target)
            {
                years++;

                double interest1 = balance * interest;
                balance += interest1;

            }

            Console.WriteLine($"THE YEARS IT TAKE TO EARN MORE THAN 100000: {years}");




        }
    }
}
