﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NagaLakshmi_Assessment_1
{
    class Car
    {
        public string Model { get; set; }

        public int Year {  get; set; }


        public void Write(string path)
        {
            using (StreamWriter sw = new StreamWriter(path))
            {
                sw.WriteLine(Model);
                sw.WriteLine(Year);


            }
             
        }


    }

    class Car2
    {
        static void Main(string[] args)
        {
            Car c = new Car();
            Console.WriteLine("enter car model");

            c.Model = Console.ReadLine();
            Console.WriteLine("enter year of making car");
            c.Year = int.Parse(Console.ReadLine());

            Console.WriteLine("enter file path to store the car details");
            string path=Console.ReadLine();
            c.Write(path);

            

              


        }
    }

}
